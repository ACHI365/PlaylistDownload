IF .exe file don't respond for too long, just press any key on keyboard and it wil work
